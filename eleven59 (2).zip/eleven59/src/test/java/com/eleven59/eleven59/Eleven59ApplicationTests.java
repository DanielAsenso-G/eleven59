package com.eleven59.eleven59;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Eleven59ApplicationTests {

	@Test
	void contextLoads() {
	}

}
