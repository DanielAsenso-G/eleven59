package com.eleven59.eleven59.repository;

import com.eleven59.eleven59.model.FlexibleActivity;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface FlexibleActivities extends MongoRepository<FlexibleActivity, String> {

}
