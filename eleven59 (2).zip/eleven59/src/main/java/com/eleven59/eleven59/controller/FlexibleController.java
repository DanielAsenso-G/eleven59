package com.eleven59.eleven59.controller;

public class FlexibleController {

}
