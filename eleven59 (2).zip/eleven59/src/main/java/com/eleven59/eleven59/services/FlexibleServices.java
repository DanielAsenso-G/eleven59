package com.eleven59.eleven59.services;

public class FlexibleServices {
}
